/*
     Title: Traveling Salesman Personal Project_Swieder    
     Author: Blaine Swieder
     Date:  June 16th, 2025    
     Purpose:   Traveling Salesman - find the lowest cost
                tour when traveling from US to 8 other countries
                and then back to US.
*/

#include <iostream>
#include <fstream>
#include <algorithm>
#include <climits>
#include "GraphMatrix.h"
using namespace std;

const int SIZE = 10;
const string COUNTRY_CODES[SIZE] = {"AU", "BR", "CA", "CN", "GL", "IT", "NA", "RU", "US", "US"};

struct Tour
{
    string tour[SIZE];
    int cost;
};

int searchCountryCode(string);
GraphMatrix* readFileMakeMatrix();
void printStringArray(string* arr, int size);
void lexicographicPermute(string* countries, int size, Tour* tourOptions, GraphMatrix* matrix, int& tourCount);

int main()
{
    Tour* tourOptions = new Tour[40320];
    GraphMatrix* matrix = readFileMakeMatrix();
    string* countries = new string[SIZE - 2];

    cout << "\n\n*************************COUNTRIES*******************\n";
    for (int x = 0; x < SIZE - 2; x++)
    {
        countries[x] = COUNTRY_CODES[x];
        cout << countries[x] << endl;
    }

    int tourCount = 0;
    lexicographicPermute(countries, SIZE - 2, tourOptions, matrix, tourCount);

    int minCost = INT_MAX;
    int bestIndex = -1;
    for (int i = 0; i < tourCount; i++)
    {
        if (tourOptions[i].cost < minCost)
        {
            minCost = tourOptions[i].cost;
            bestIndex = i;
        }
    }

    cout << "\n\n*************************SOLUTION*******************\n";
    cout << "\nLowest Cost Tour: ";
    printStringArray(tourOptions[bestIndex].tour, SIZE);
    cout << "Cost: $" << tourOptions[bestIndex].cost << endl;

    delete[] countries;
    delete[] tourOptions;
    delete matrix;

    cout << "\nHappy Traveling!\n";
    return 0;
}

int searchCountryCode(string code)
{
    int low = 0, high = SIZE - 1;
    while (low <= high)
    {
        int mid = (low + high) / 2;
        if (COUNTRY_CODES[mid] == code)
            return mid;
        else if (COUNTRY_CODES[mid] < code)
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1;
}

GraphMatrix* readFileMakeMatrix()
{
    ifstream inFile;
    GraphMatrix* matrix = new GraphMatrix(SIZE - 1);
    cout << "\nCreated the matrix.";
    string country1, country2;
    int price;
    inFile.open("flights.txt");
    cout << "\nReading from flights.txt\n";
    if (inFile)
    {
        while (inFile >> country1)
        {
            inFile >> country2;
            inFile >> price;
            matrix->addEdge(searchCountryCode(country1), searchCountryCode(country2), price);
            cout << "\nAdded edge from " << country1 << " to " << country2 << " with cost of $" << price;
        }
    }
    else
        cout << "\nSorry, I am unable to open the file.\n";
    inFile.close();
    cout << "\n\nFLIGHT PRICE GRAPH MATRIX\n";
    matrix->printGraph();
    cout << endl;
    return matrix;
}

void printStringArray(string* arr, int size)
{
    for (int x = 0; x < size; x++)
    {
        cout << arr[x] << " ";
    }
    cout << endl;
}

void lexicographicPermute(string* countries, int size, Tour* tourOptions, GraphMatrix* matrix, int& tourCount)
{
    sort(countries, countries + size);
    do
    {
        Tour t;
        t.tour[0] = "US";
        for (int i = 0; i < size; i++)
            t.tour[i + 1] = countries[i];
        t.tour[size + 1] = "US";

        t.cost = 0;
        for (int i = 0; i < size + 1; i++)
        {
            int from = searchCountryCode(t.tour[i]);
            int to = searchCountryCode(t.tour[i + 1]);
            t.cost += matrix->getWeight(from, to);
        }

        tourOptions[tourCount++] = t;
    } while (next_permutation(countries, countries + size));
}






























